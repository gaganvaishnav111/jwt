package org.revature.revhire;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RevhireApplication {

	public static void main(String[] args) {
		SpringApplication.run(RevhireApplication.class, args);
	}

}
