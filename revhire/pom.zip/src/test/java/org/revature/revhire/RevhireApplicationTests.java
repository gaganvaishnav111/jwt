package org.revature.revhire;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RevhireApplicationTests {

	@Test
	void contextLoads() {
	}

}
